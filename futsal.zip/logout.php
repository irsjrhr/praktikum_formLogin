<?php 

require_once 'fungsi.php';


session_destroy();
header('location:login.php');