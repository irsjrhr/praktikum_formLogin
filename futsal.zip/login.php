<?php 
//VARIABEL SUPER GLOBAL

//Session
require_once 'fungsi.php';


//Validasi 
if ( isset($_POST['user']) ) {
	$user = $_POST['user'];
	$password = $_POST['password'];

	if ( $user == $data['user'] ) {
		if ($password == $data['password']) {
			
			buat_sesi();
			header('location:index.php');

		}else{
			echo "Password salah";
		}
	}else{
		echo "Gagal login, data user tidak ada";
	}

}

if ( isset($_SESSION['nama'])) {
	header('location:index.php');
}


// $a = 1;
// function cetak(){
// 	global $a;
// 	echo $a;
// 	$b = 2;
// }

// cetak();
// echo $b;
?>




<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		Halaman Login
	</title>
	<style type="text/css">
		form{
			width: 50%;
			height: auto;
			margin: auto;
			border: 2px solid #000;
			padding: 20px;
			box-sizing: border-box;
		}
		input, button{
			width: 100%;
			height: auto;
			padding: 20px;
			font-size: 20px;
			box-sizing: border-box;
			margin-bottom: 20px;
		}
		h1{
			text-align: center;
		}
	</style>
</head>
<body>

	<form action="" method="post">
		<h1> Login Form </h1>
		<input type="text" placeholder="user" name="user">
		<input type="text" placeholder="password" name="password">
		<button type="submit">
			Login
		</button>
	</form>

</body>
</html>
