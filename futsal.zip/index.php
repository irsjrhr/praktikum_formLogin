<?php 
require_once 'fungsi.php';


// require_once 'index.php';
// // unset($_SESSION['nama']);

var_dump($_SESSION);
cek_sesi();

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>
		Halaman Praktikum
	</title>
</head>
<body>


<h1> Halaman index </h1>

</body>
</html>

